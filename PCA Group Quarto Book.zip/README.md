# Fall-2023

This GitHub hosts the PCA project authored by Gail Han, Hector Gavilanes, and Michael Mezzano for STA6257 at the University of West Florida in the Fall 2023 semester.
https://sta6257-pca.github.io/Fall-2023/
